import UIKit
class ListViewController<Cell: DynamicDataCell, DataType: Codable>: UIViewController, UIScrollViewDelegate where Cell: UITableViewCell {
  var viewData: [DataType]?
  var isScrolledUp: (() -> Void)?
  private var titleLabel: UILabel = {
    let label = UILabel()
    label.textColor = .black
    label.font = UIFont.boldSystemFont(ofSize: 28.0)
    label.adjustsFontForContentSizeCategory = true
    label.text = "Ozzum Pizza"
    label.textAlignment = .center
    return label
  }()
  private var containerView: UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.cornerRadius = 30
    view.clipsToBounds = true
    view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
    return view
  }()
  private var overlayView: UIView! = {
    let view = UIView()
    view.backgroundColor = UIColor.clear
    return view
  }()
  var shouldShowFloatingButton: Bool = false {
    didSet {
      if shouldShowFloatingButton {
        self.addFloatingButton()
      }
    }
  }
  private var floatingButton: FloatingButton = {
    let button = FloatingButton()
    return button
  }()
  var listTableView: UITableView = {
    let table = UITableView()
    table.translatesAutoresizingMaskIntoConstraints = false
    return table
  }()
  private var listDataSource: ListTableViewDataSource<Cell, DataType>!
  private var listDelegate: ListTableViewDelegate!
  fileprivate func addFloatingButton() {
    floatingButton.frame = CGRect(x: self.view.bounds.width*0.75, y: self.view.bounds.height*0.85, width: 80, height: 80)
    self.view.addSubview(floatingButton)
    floatingButton.buttonPressedAction = { [weak self] in
      guard let self = self else { return }
      
    }
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    addOverLayView()
    addContainerView()
    configureTable()
    addTitleLabel()
    addTableView()
  }
  private func configureView() {
    view.backgroundColor = .white
    view.layer.cornerRadius = 10
    view.clipsToBounds = true
    view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
  }
  private func configureTable() {
    listTableView.register(UINib(nibName: String(describing: Cell.self), bundle: nil), forCellReuseIdentifier: String(describing: Cell.self))
    listDataSource = ListTableViewDataSource<Cell, DataType>()
    listDataSource.dataSource = viewData
    listTableView.rowHeight = UITableView.automaticDimension
    listDelegate = ListTableViewDelegate(delegate: self)
    listTableView.dataSource = listDataSource
    listTableView.delegate = listDelegate
  }
  private func addTitleLabel() {
    self.containerView.addSubview(titleLabel)
    titleLabel.translatesAutoresizingMaskIntoConstraints = false
    titleLabel.leadingAnchor.constraint(equalTo: self.containerView.leadingAnchor, constant: .zero).isActive = true
    titleLabel.trailingAnchor.constraint(equalTo: self.containerView.trailingAnchor, constant: .zero).isActive = true
    titleLabel.topAnchor.constraint(equalTo: self.containerView.topAnchor, constant: 40).isActive = true
    titleLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
    titleLabel.widthAnchor.constraint(equalToConstant: self.containerView.bounds.width).isActive = true
  }
  private func addTableView() {
    self.containerView.addSubview(listTableView)
    listTableView.translatesAutoresizingMaskIntoConstraints = false
    listTableView.leadingAnchor.constraint(equalTo: self.containerView.leadingAnchor, constant: .zero).isActive = true
    listTableView.trailingAnchor.constraint(equalTo: self.containerView.trailingAnchor, constant: .zero).isActive = true
    listTableView.topAnchor.constraint(equalTo: self.titleLabel.bottomAnchor, constant: .zero).isActive = true
    listTableView.bottomAnchor.constraint(equalTo: self.containerView.bottomAnchor, constant: .zero).isActive = true
  }
  private func addOverLayView() {
    self.view.addSubview(overlayView)
    overlayView.translatesAutoresizingMaskIntoConstraints = false
    overlayView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: .zero).isActive = true
    overlayView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: .zero).isActive = true
    overlayView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: .zero).isActive = true
    overlayView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: .zero).isActive = true
  }
  private func addContainerView() {
    self.overlayView.addSubview(containerView)
    containerView.translatesAutoresizingMaskIntoConstraints = false
    containerView.leadingAnchor.constraint(equalTo: overlayView.leadingAnchor, constant: .zero).isActive = true
    containerView.trailingAnchor.constraint(equalTo: overlayView.trailingAnchor, constant: .zero).isActive = true
    containerView.bottomAnchor.constraint(equalTo: overlayView.bottomAnchor, constant: .zero).isActive = true
    containerView.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 1).isActive = true
  }
  

}
extension ListViewController: ListCallBacK {
  func userScrolledUp() {
    listTableView.isScrollEnabled = false
    self.isScrolledUp?()
  }
  func didSelectionOfRow(_ indexPath: IndexPath) {
  }
}
