import Foundation
struct Constants {
  struct Assets {
    static let imageName = "Offer"
  }
}
