import UIKit
protocol DynamicDataCell {
  associatedtype DataType
  func configure(_ dataType: DataType?)
}
class ListItemCell: UITableViewCell, DynamicDataCell {
  typealias DataType = Item
  @IBOutlet weak var titleLabel: UILabel!
  @IBOutlet weak var btnAddToCart: UIButton!
  @IBOutlet weak var detailsLabel: UILabel!
  @IBAction func addToCartTapped(_ sender: Any) {
  }
  override func awakeFromNib() {
    super.awakeFromNib()
    self.selectionStyle = .none
    // Initialization code
  }
  override func setSelected(_ selected: Bool, animated: Bool) {
    super.setSelected(selected, animated: animated)
    
    // Configure the view for the selected state
  }
  func configure(_ dataType: Item?) {
    guard let safeItem = dataType else { return }
    titleLabel.text = safeItem.title
    detailsLabel.text = safeItem.details
  }
}
