import UIKit
class CarouselViewController: UIPageViewController {
  var hightLightImages: [UIImage?] = [UIImage(named: Constants.Assets.imageName), UIImage(named: Constants.Assets.imageName), UIImage(named: Constants.Assets.imageName),  UIImage(named: Constants.Assets.imageName)]
  private lazy var hightlightItems: [UIViewController] = []
  override func viewDidLoad() {
    super.viewDidLoad()
    dataSource = self
    self.view.backgroundColor = .clear
    createHighlightItems()
  }
  override init(transitionStyle style: UIPageViewController.TransitionStyle, navigationOrientation: UIPageViewController.NavigationOrientation, options: [UIPageViewController.OptionsKey : Any]? = nil) {
    super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
  }
  required init?(coder: NSCoder) {
    super.init(coder: coder)
  }
  override func viewDidLayoutSubviews() {
    super.viewDidLayoutSubviews()
    for subView in self.view.subviews {
      if subView is UIScrollView {
        subView.frame = self.view.bounds
      }
      else if subView is UIPageControl {
        self.view.bringSubviewToFront(subView)
      }
    }
  }
  private func createHighlightItems() {
    hightLightImages.forEach({ (eachImage) in
      guard let image = eachImage else { return }
      let item = HighlightViewController(image)
      hightlightItems.append(item)
    })
    setFirstViewController()
    configurePageControl()
  }
  private func setFirstViewController() {
    if let firstItem = hightlightItems.first as? HighlightViewController {
      self.setViewControllers([firstItem], direction: .forward, animated: true, completion: nil)
    }
  }
  private func configurePageControl() {
    let pagecontrol = UIPageControl.appearance(whenContainedInInstancesOf: [CarouselViewController.self])
    pagecontrol.currentPageIndicatorTintColor = .white
    pagecontrol.pageIndicatorTintColor = .gray
    pagecontrol.backgroundColor = .clear
  }
}
extension CarouselViewController: UIPageViewControllerDataSource {
  func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
    guard let viewControllerIndex = hightlightItems.firstIndex(of: viewController) else {
      return nil
    }
    let previousIndex = viewControllerIndex - 1
    guard previousIndex >= 0 else {
      return nil
    }
    guard hightlightItems.count > previousIndex else {
      return nil
    }
    return hightlightItems[previousIndex]
  }
  
  func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
    guard let viewControllerIndex = hightlightItems.firstIndex(of: viewController) else {
      return nil
    }
    let nextIndex = viewControllerIndex + 1
    guard hightlightItems.count != nextIndex else {
      return nil
    }
    guard hightlightItems.count > nextIndex else {
      return nil
    }
    return hightlightItems[nextIndex]
  }
  func presentationCount(for _: UIPageViewController) -> Int {
    return hightlightItems.count
  }
  func presentationIndex(for _: UIPageViewController) -> Int {
    guard let firstViewController = viewControllers?.first,
          let firstViewControllerIndex = hightlightItems.firstIndex(of: firstViewController) else {
      return 0
    }
    return firstViewControllerIndex
  }
}
