import UIKit
class CartTableViewCell: UITableViewCell, DynamicDataCell  {
  typealias DataType = Item
  override func awakeFromNib() {
    super.awakeFromNib()
    self.selectionStyle = .none
    // Initialization code
  }
  @IBOutlet weak var titleLbl: UILabel!
  @IBOutlet weak var detailLbl: UILabel!
  override func setSelected(_ selected: Bool, animated: Bool) {
    super.setSelected(selected, animated: animated)
    
    // Configure the view for the selected state
  }
  func configure(_ dataType: Item?) {
    guard let safeItem = dataType else { return }
    titleLbl.text = safeItem.title
    detailLbl.text = safeItem.details
  }
}
