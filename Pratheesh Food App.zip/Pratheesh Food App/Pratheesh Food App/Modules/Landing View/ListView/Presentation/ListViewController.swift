import UIKit
class ListViewController<Cell: DynamicDataCell, DataType: Codable>: UIViewController where Cell: UITableViewCell {
  private var listTableView: UITableView = {
    let table = UITableView()
    table.translatesAutoresizingMaskIntoConstraints = false
    return table
  }()
  private var listDataSource: ListTableViewDataSource<Cell, DataType>!
  private var listDelegate: ListTableViewDelegate!
  override func viewDidLoad() {
    super.viewDidLoad()
    configureTable()
    addTableView()
  }
  private func configureView() {
    view.backgroundColor = .white
    view.layer.cornerRadius = 10
    view.clipsToBounds = true
    view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
  }
  private func configureTable() {
    listTableView.register(UINib(nibName: String(describing: Cell.self), bundle: nil), forCellReuseIdentifier: String(describing: Cell.self))
    listDataSource = ListTableViewDataSource<Cell, DataType>()
    listDataSource.dataSource = [Item(title: "Test1", details: "Test1"),
                                 Item(title: "Test1", details: "Test1"),
                                 Item(title: "Test1", details: "Test1"),
                                 Item(title: "Test1", details: "Test1")] as? [DataType]
    listTableView.rowHeight = UITableView.automaticDimension
    listDelegate = ListTableViewDelegate(delegate: self)
    listTableView.dataSource = listDataSource
    listTableView.delegate = listDelegate
  }
  private func addTableView() {
    self.view.addSubview(listTableView)
    listTableView.translatesAutoresizingMaskIntoConstraints = false
    listTableView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: .zero).isActive = true
    listTableView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: .zero).isActive = true
    listTableView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: .zero).isActive = true
    listTableView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: .zero).isActive = true
  }
}
extension ListViewController: ListCallBacK {
  func didSelectionOfRow(_ indexPath: IndexPath) {
  }
}
