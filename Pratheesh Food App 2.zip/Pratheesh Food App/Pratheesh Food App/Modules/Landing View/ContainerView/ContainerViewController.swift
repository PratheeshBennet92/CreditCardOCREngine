import UIKit
class ContainerViewController: UIViewController {
  private var listViewController: ListViewController<ListItemCell, Item> = {
    let listViewController = ListViewController<ListItemCell, Item>()
    listViewController.viewData = [Item(title: "Test1", details: "Test1"),
                  Item(title: "Test1", details: "Test1"),
                  Item(title: "Test1", details: "Test1"),
                  Item(title: "Test1", details: "Test1")]
    listViewController.shouldShowFloatingButton = true
    return listViewController
  }()
  private var carouselViewController = CarouselViewController()
  private var tableTopZeroConstraint: NSLayoutConstraint?
  private var tableTopHeroConstraint: NSLayoutConstraint?
    override func viewDidLoad() {
        super.viewDidLoad()
      self.view.backgroundColor = .red
      setupHeightConstraints()
      addCarousel()
      addListView()
      scrolledUpObserver()
        // Do any additional setup after loading the view.
    }
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
  }
  private func setupHeightConstraints() {
    tableTopZeroConstraint =  self.listViewController.view.topAnchor.constraint(equalTo: self.view.topAnchor)
    tableTopHeroConstraint =  self.listViewController.view.topAnchor.constraint(equalTo: self.view.topAnchor, constant: self.view.bounds.height * 0.7)
  }
  private func addListView() {
    self.addChild(listViewController)
    self.view.addSubview(listViewController.view)
    self.listViewController.view.translatesAutoresizingMaskIntoConstraints  = false
    self.listViewController.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0).isActive = true
    self.listViewController.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0).isActive = true
    //self.listViewController.view.topAnchor.constraint(equalTo: self.carouselViewController.view.bottomAnchor).isActive = true
    tableTopZeroConstraint?.isActive = false
    tableTopHeroConstraint?.isActive = true
    self.listViewController.view.heightAnchor.constraint(equalToConstant: self.view.bounds.height).isActive = true
    listViewController.didMove(toParent: self)
  }
  private func addCarousel() {
    self.addChild(carouselViewController)
    self.view.addSubview(carouselViewController.view)
    self.carouselViewController.view.translatesAutoresizingMaskIntoConstraints  = false
    self.carouselViewController.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0).isActive = true
    self.carouselViewController.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0).isActive = true
    self.carouselViewController.view.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0).isActive = true
    self.carouselViewController.view.heightAnchor.constraint(equalToConstant: self.view.bounds.height * 0.7).isActive = true
    carouselViewController.didMove(toParent: self)
  }
  private func scrolledUpObserver() {
    listViewController.isScrolledUp = { [weak self] in
      guard let self = self else { return }
      //self.tableTopHeroConstraint?.isActive = false
      self.tableTopZeroConstraint?.isActive = true
      UIView.animateKeyframes(withDuration: 0.45, delay: 0, options: .calculationModePaced) {
        self.view.layoutIfNeeded()
      } completion: { (_) in
        self.listViewController.listTableView.isScrollEnabled =  true
      }

    }
  }
}
