import UIKit
class CellConfigurator<CellType: DynamicDataCell, DataType: Codable> where CellType: UITableViewCell  {
  var item: DataType?
  var cell: CellType?
  init(item: DataType, cell: CellType) {
    self.item = item
    self.cell = cell
    configure()
  }
  func configure() {
    cell?.configure(item as? CellType.DataType)
  }
}
