import UIKit
protocol ListCallBacK: class {
  func didSelectionOfRow(_ indexPath: IndexPath)
  func userScrolledUp()
}
class ListTableViewDelegate: NSObject, UITableViewDelegate, UIScrollViewDelegate {
  private var isScrolledUp: Bool = false
  weak var delegate: ListCallBacK?
  var lastContentOffset: CGFloat = 0
  init(delegate: ListCallBacK) {
    self.delegate = delegate
  }
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    self.delegate?.didSelectionOfRow(indexPath)
  }
  func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
      self.lastContentOffset = scrollView.contentOffset.y
  }
  func scrollViewDidScroll(_ scrollView: UIScrollView) {
      if self.lastContentOffset < scrollView.contentOffset.y {
        if !isScrolledUp {
          self.delegate?.userScrolledUp()
          isScrolledUp = true
        }
      }
  }
}
