import UIKit
class ListTableViewDataSource<Cell: DynamicDataCell, DataType: Codable>: NSObject, UITableViewDataSource where Cell: UITableViewCell {
  var dataSource: [DataType]?
  var configurator: CellConfigurator<Cell, DataType>!
  override init() {
    super.init()
  }
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return dataSource?.count ?? 0
  }
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: Cell.self)) as? Cell else {
      return UITableViewCell()
    }
    if let configItem = dataSource?[indexPath.row] {
      configurator = CellConfigurator<Cell, DataType>(item: configItem, cell: cell)
    }
    return cell
  }
}
