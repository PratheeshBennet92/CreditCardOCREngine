import UIKit
protocol ListCallBacK: class {
  func didSelectionOfRow(_ indexPath: IndexPath)
}
class ListTableViewDelegate: NSObject, UITableViewDelegate {
  weak var delegate: ListCallBacK?
  init(delegate: ListCallBacK) {
    self.delegate = delegate
  }
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    self.delegate?.didSelectionOfRow(indexPath)
  }

}
