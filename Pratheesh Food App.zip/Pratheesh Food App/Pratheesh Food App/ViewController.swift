//
//  ViewController.swift
//  Pratheesh Food App
//
//  Created by Christina Taflin on 04/11/20.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    let a = ListViewController<ListItemCell, Item>()
    a.modalPresentationStyle = .overFullScreen
    self.present(a, animated: true, completion: nil)
  }


}

