import Foundation
struct Item: Codable {
  let  title: String?
  let  details: String?
}
