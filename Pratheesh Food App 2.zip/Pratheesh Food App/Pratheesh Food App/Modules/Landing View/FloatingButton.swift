import UIKit
class FloatingButton: UIButton {
  var buttonPressedAction: (() -> Void)?
  override init(frame: CGRect) {
    super.init(frame: frame)
    configureButton()
  }
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  private func configureButton() {
    self.setTitle("Order", for: .normal)
    self.backgroundColor = .systemGreen
    self.clipsToBounds = true
    self.layer.cornerRadius = 40
    self.addTarget(self, action: #selector(animateOnTap), for: .touchUpInside)
  }
  @objc func animateOnTap() {
    UIView.animate(withDuration: 0.15,
                   animations: { [weak self] in
                    guard let self = self else { return }
                    self.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
                    self.buttonPressedAction?()
                   },
                   completion: { _ in
                    UIView.animate(withDuration: 0.15) {
                      self.transform = CGAffineTransform.identity
                    }
                   })
  }
  func removeButton() {
    self.removeFromSuperview()
  }
}
